document.addEventListener('DOMContentLoaded', () => {
  // scroll
  document.querySelectorAll('a[href^="#"]').forEach(link => {
    link.addEventListener('click', function(e) {
      e.preventDefault();
      const target = document.querySelector(this.getAttribute('href'));
      target.scrollIntoView({ behavior: 'smooth' });
    });
  });

  // Project Filter and Slider Logic
  const categoriesContainer = document.querySelector('.categories');
  const projectSlider = document.querySelector('.projects-slider');
  const projectCards = document.querySelectorAll('.project-card-new');
  const prevBtn = document.querySelector('.prev-btn');
  const nextBtn = document.querySelector('.next-btn');

  let currentIndex = 0;
  let filteredProjects = Array.from(projectCards);

  // Function to update the slider based on the current index
  function updateSlider() {
    if (filteredProjects.length === 0) {
      projectSlider.style.transform = 'translateX(0)';
      return;
    }
    const offset = -currentIndex * 100;
    projectSlider.style.transform = `translateX(${offset}%)`;
    updateButtons();
  }

  // Function to update the visibility of slider buttons
  function updateButtons() {
    prevBtn.disabled = currentIndex === 0;
    nextBtn.disabled = currentIndex === filteredProjects.length - 1;
    prevBtn.style.opacity = prevBtn.disabled ? '0.5' : '1';
    nextBtn.style.opacity = nextBtn.disabled ? '0.5' : '1';
  }

  // Handle category filtering
  categoriesContainer.addEventListener('click', (e) => {
    if (e.target.tagName === 'BUTTON') {
      const category = e.target.dataset.category;

      // Remove active class from all buttons
      document.querySelectorAll('.category-btn').forEach(btn => btn.classList.remove('active'));
      // Add active class to the clicked button
      e.target.classList.add('active');

      // Filter projects based on category
      filteredProjects = Array.from(projectCards).filter(card => {
        const isMatch = category === 'all' || card.classList.contains(category);
        card.style.display = isMatch ? 'flex' : 'none';
        return isMatch;
      });

      currentIndex = 0;
      updateSlider();
    }
  });

  // Handle slider navigation
  nextBtn.addEventListener('click', () => {
    if (currentIndex < filteredProjects.length - 1) {
      currentIndex++;
      updateSlider();
    }
  });

  prevBtn.addEventListener('click', () => {
    if (currentIndex > 0) {
      currentIndex--;
      updateSlider();
    }
  });

  // Initial setup
  updateSlider();
});